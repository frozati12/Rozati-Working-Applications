from fastapi_camelcase import CamelModel
from typing import Optional

class agentReservation(CamelModel):
    reservation_id: Optional[str]
    passenger_name : Optional[str]
    reservation_date: Optional[str]
    reference_number: Optional[str]
    record_locator_id: Optional[str]
    total_cost: Optional[int]

class airline(CamelModel):
    airline_id: Optional[str]
    airline_name: Optional[str]
    hub: Optional[str]
    website: Optional[str]
    phone_number: Optional[int]
    aircraft_type: Optional[str]

class hub(CamelModel):
    hub_id: Optional[str]
    airport_code: Optional[str]
    airport_name: Optional[str]
    airline_count: Optional[int]
    destination_count: Optional[int]

class passenger(CamelModel):
    passenger_id: Optional[str]
    first_name: Optional[str]
    surname: Optional[str]
    email_address: Optional[str]
    age: Optional[int]

class recordLocator(CamelModel):
    record_locator_id: Optional[str]
    airline_record_locator: Optional[str]
    fare_class: Optional[str]
    bag_count: Optional[int]
    departure: Optional[str]
    arrival: Optional[str]
    connections: Optional[str]
