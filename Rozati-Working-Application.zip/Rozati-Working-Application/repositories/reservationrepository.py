# The following file contains the list of some of the most common statements and queries that may be made for each table
import uuid
from typing import List

from models.reservation_model import agentReservation, airline, hub, passenger, recordLocator
from repositories.db_connection import DBConnection

# SQL GET Commands to view ALL the data in each of the tables
GET_AGENT_RESERVATIONS = "SELECT * FROM Rozati.agentreservation"
GET_AIRLINE_DETAILS = "SELECT * FROM Rozati.airline"
GET_HUB_INFO = "SELECT * FROM Rozati.hub"
GET_PASSENGER_DETAILS = "SELECT * FROM Rozati.passenger"
GET_RECORD_LOCATORS = "SELECT * FROM Rozati.recordlocator"

# SQL GET (by id) Commands to view data in each table specified by primary key
GET_AGENT_RESERVATION_BY_ID = "SELECT * FROM Rozati.agentreservation WHERE reservation_id = %s"
GET_AIRLINE_DETAILS_BY_ID = "SELECT * FROM Rozati.airline WHERE airline_id = %s"
GET_HUB_INFO_BY_ID = "SELECT * FROM Rozati.hub WHERE hub_id = %s"
GET_PASSENGER_DETAILS_BY_ID = "SELECT * FROM Rozati.passenger WHERE passenger_id = %s"
GET_RECORD_LOCATOR_BY_ID = "SELECT * FROM Rozati.recordlocator WHERE record_locator_id = %s"

# SQL POST (INSERT Command) to be able to add data to each of the tables
POST_PASSENGER = "INSERT INTO Rozati.passenger(gen_random_uuid(), first_name, surname, phone_number, email_address, age)"
POST_RECORD_LOCATOR = "INSERT INTO Rozati.recordlocator(gen_random_uuid(), airline_record_locator, passenger_id, fare_class, bag_count, departure, arrival, connections)"
POST_AGENT_RESERVATION = "INSERT INTO Rozati.agentreservation(gen_random_uuid(), passenger_name, reservation_date, reference_number, record_locator_id, total_cost)"
POST_HUB_DETAILS = "INSERT INTO Rozati.hub(gen_random_uuid(), airport_code, airport_name, airline_count, destination_count)"
POST_AIRLINE_DETAILS = "INSERT INTO Rozati.airline(gen_random_uuid(), airline_name, hub, website, phone_number, aircraft_type)"

# SQL PUT (UPDATE Command) to be able to update data in each table
PUT_AGENT_RESERVATION_BY_ID = "UPDATE Rozati.agentreservation SET passenger_name=%s, reservation_date=%s, reference_number=%s, record_locator_id=%s, total_cost=%s"
PUT_AIRLINE_DETAILS_BY_ID = "UPDATE Rozati.airline SET airline_name=%s, hub=%s, website=%s, phone_number=%s, aircraft_type=%s, WHERE reservation_id = %s"
PUT_HUB_DETAILS_BY_ID = "UPDATE Rozati.hub SET airport_code=%s, airport_name=%s, airline_count=%s, destination_count=%s, WHERE hub_id = %s"
PUT_PASSENGER_BY_ID = "UPDATE Rozati.passenger SET first_name=%s, surname=%s, phone_number=%s, email_address=%s, age=%s, WHERE passenger_id = %s"
PUT_RECORD_LOCATOR_BY_ID = "UPDATE Rozati.recordlocator SET airline_record_locator=%s, passenger_id=%s, fare_class=%s, bag_count=%s, departure=%s, arrival=%s, connections=%s WHERE record_locator_id = %s"

# SQL DELETE to be able to delete data in each table
DELETE_AGENT_RESERVATIONS = "DELETE FROM Rozati.agentreservation WHERE reservation_id=%s"
DELETE_AIRLINE = "DELETE FROM Rozati.airline WHERE airline_id=%s"
DELETE_HUB = "DELETE FROM Rozati.hub WHERE hub_id=%s"
DELETE_PASSENGER = "DELETE FROM Rozati.passenger WHERE passenger_id=%s"
DELETE_RECORD_LOCATOR = "DELETE FROM Rozati.recordlocator WHERE record_locator_id=%s"

####################################################################################################
# GET ALL functions begin here
def get_all_agent_reservations() -> List[agentReservation]:
    reservations = []
    db = DBConnection()
    cur = db.get.cursor()
    cur.execute(GET_AGENT_RESERVATIONS)
    for row in cur:
        reservations.append(
            agentReservation(reservationId=str(row[0]), passengerName=str(row[1]), reservationDate=str(row[2]),
                             referenceNumber=str(row[3]), recordLocatorId=str(row[4]), totalCost=int(row[5])))
    return reservations


def get_all_airline_details() -> List[airline]:
    airlines = []
    db = DBConnection()
    cur = db.getcursor()
    cur.execute(GET_AIRLINE_DETAILS)
    for row in cur:
        airlines.append(
            airline(airlineId=str(row[0]), airlineName=str(row[1]), hub=str(row[2]), website=str(row[3]),
                    phoneNumber=str(row[4]), aircraftType=str(row[5]))
        )
    return airlines


def get_all_hub_info() -> List[hub]:
    hubs = []
    db = DBConnection()
    cur = db.getcursor()
    cur.execute(GET_HUB_INFO)
    for row in cur:
        hubs.append(
            hub(hubId=str(row[0]), airportCode=str(row[1]), airport_name=str(row[2]), airline_count=int(row[3]),
                destination_count=int(row[4]))
        )
    return hubs


def get_all_passenger_details() -> List[passenger]:
    passengers = []
    db = DBConnection()
    cur = db.getcursor()
    cur.execute(GET_PASSENGER_DETAILS)
    for row in cur:
        passengers.append(
            passenger(passengerId=str(row[0]), firstName=str(row[1]), surname=str(row[2]), phoneNumber=str(row[3]),
                      emailAddress=str(row[4]), age=int(row[5]))
        )
    return passengers


def get_all_record_locators() -> List[recordLocator]:
    recordlocators = []
    db = DBConnection()
    cur = db.getcursor()
    cur.execute(GET_RECORD_LOCATORS)
    for row in cur:
        recordlocators.append(
            recordLocator(recordLocatorId=str(row[0]), airlineRecordLocator=str(row[1]), passengerId=str(row[2]),
                          fareClass=str(row[3]), bagCount=str(row[4]), departure=str(row[5]), arrival=str(row[6]),
                          connections=str(row[7]))
        )
    return recordlocators

####################################################################################################
# GET BY ID functions begin here
def get_reservation_by_id(uid: uuid) -> agentReservation:
    db = DBConnection()
    cur = db.get_cursor()
    cur.execute(GET_AGENT_RESERVATION_BY_ID, [uid])
    for row in cur:
        reservation = agentReservation(reservationId=str(row[0]), passengerName=str(row[1]),
                                       reservationDate=str(row[2]), referenceNumber=str(row[3]),
                                       recordLocatorId=str(row[4]), totalCost=int([row]))
        return reservation


def get_airline_details_by_id(uid: uuid) -> airline:
    db = DBConnection()
    cur = db.get_cursor()
    cur.execute(GET_AIRLINE_DETAILS_BY_ID, [uid])
    for row in cur:
        airlines = airline(airlineId=str(row[0]), airlineName=str(row[1]), hub=str(row[2]), website=str(row[3]),
                           phoneNumber=str(row[4]), aircraftType=str(row[5]))
        return airlines


def get_hub_info_by_id(uid: uuid) -> hub:
    db = DBConnection()
    cur = db.get_cursor()
    cur.execute(GET_HUB_INFO_BY_ID, [uid])
    for row in cur:
        hubs = hub(hubId=str(row[0]), airportCode=str(row[1]), airport_name=str(row[2]), airline_count=int(row[3]),
                   destination_count=int(row[4]))
        return hubs


def get_passenger_details_by_id(uid: uuid) -> passenger:
    db = DBConnection()
    cur = db.get_cursor()
    cur.execute(GET_PASSENGER_DETAILS_BY_ID, [uid])
    for row in cur:
        passengers = passenger(passengerId=str(row[0]), firstName=str(row[1]), surname=str(row[2]),
                               phoneNumber=str(row[3]), emailAddress=str(row[4]), age=int(row[5]))
        return passengers


def get_record_locators_by_id(uid: uuid) -> recordLocator:
    db = DBConnection()
    cur = db.getcursor()
    cur.execute(GET_RECORD_LOCATOR_BY_ID, [uid])
    for row in cur:
        recordlocators = recordLocator(recordLocatorId=str(row[0]), airlineRecordLocator=str(row[1]),
                                       passengerId=str(row[2]),
                                       fareClass=str(row[3]), bagCount=str(row[4]), departure=str(row[5]),
                                       arrival=str(row[6]),
                                       connections=str(row[7]))
        return recordlocators

####################################################################################################
# POST Functions (INSERT Commands) begins here

def create_agent_reservation(agentreservation: agentReservation) -> agentReservation:
    db = DBConnection()
    cur = db.get_cursor()
    uid = uuid.uuid4()
    cur.execute(POST_AGENT_RESERVATION, (
        uid,
        agentreservation.passenger_name,
        agentreservation.reservation_date,
        agentreservation.reference_number,
        agentreservation.record_locator_id,
        agentreservation.total_cost
    ))
    db.connection.commit()
    return get_reservation_by_id(uid)

def create_airline(airlines: airline) -> airline:
    db = DBConnection()
    cur = db.get_cursor()
    uid = uuid.uuid4()
    cur.execute(POST_AIRLINE_DETAILS, (
        uid,
        airline.airline_name,
        airline.hub,
        airline.website,
        airline.phone_nuumber,
        airline.aircaft_type
    ))
    db.connection.commit()
    return get_airline_details_by_id(uid)

def create_hub(hubs: hub) -> hub:
    db = DBConnection()
    cur = db.get_cursor()
    uid = uuid.uuid4()
    cur.execute(POST_HUB_DETAILS, (
        uid,
        hub.airport_code,
        hub.airport_name,
        hub.airline_count,
        hub.destination_count
    ))
    db.connection.commit()
    return get_hub_info_by_id(uid)

def create_passenger(passengers: passenger) -> passenger:
    db = DBConnection()
    cur = db.get_cursor()
    uid = uuid.uuid4()
    cur.execute(POST_PASSENGER, (
        uid,
        passenger.first_name,
        passenger.surname,
        passenger.phone_number,
        passenger.email_address,
        passenger.age
    ))
    db.connection.commit()
    return get_passenger_details_by_id(uid)

def create_record_locator(recordlocator: recordLocator) -> recordLocator:
    db = DBConnection()
    cur = db.get_cursor()
    uid = uuid.uuid4()
    cur.execute(POST_RECORD_LOCATOR, (
        uid,
        recordLocator.airline_record_locator,
        recordLocator.passenger_id,
        recordLocator.fare_class,
        recordLocator.bag_count,
        recordLocator.departure,
        recordLocator.arrival,
        recordLocator.connections
    ))
    db.connection.commit()
    return get_record_locators_by_id(uid)

####################################################################################################
# PUT Functions (UPDATE Commands) begins here

def update_agent_reservation(agentreservation: agentReservation) -> agentReservation:
    db = DBConnection()
    cur = db.get_cursor()
    uid = uuid.UUID(agentreservation.reservation_id)
    cur.execute(PUT_AGENT_RESERVATION_BY_ID, (agentreservation.passenger_name, agentreservation.reservation_date, agentreservation.reference_number, agentreservation.record_locator_id, agentreservation.total_cost))
    db.connection.commit
    return get_reservation_by_id(uid)

def update_airline_details(airlines: airline) -> airline:
    db = DBConnection()
    cur = db.get_cursor()
    uid = uuid.UUID(airline.airline_id)
    cur.execute(PUT_AIRLINE_DETAILS_BY_ID, (airline.airline_name, airline.hub, airline.website, airline.phone_number, airline.aircraft_type))
    db.connection.commit
    return get_airline_details_by_id(uid)

def update_hub_details(hubs: hub) -> hub:
    db = DBConnection()
    cur = db.get_cursor()
    uid = uuid.UUID(hub.hub_id)
    cur.execute(PUT_HUB_DETAILS_BY_ID, (hub.airport_code, hub.airport_name, hub.airline_count, hub.destination_count))
    db.connection.commit
    return get_hub_info_by_id(uid)

def update_passenger_details(passengers: passenger) -> passenger:
    db = DBConnection()
    cur = db.get_cursor()
    uid = uuid.UUID(passenger.passenger_id)
    cur.execute(PUT_PASSENGER_BY_ID, (passenger.first_name, passenger.surname, passenger.phone_number, passenger.email_address, passenger.age))
    db.connection.commit
    return get_passenger_details_by_id(uid)

def update_recordlocator_details(recordlocator: recordLocator) -> recordLocator:
    db = DBConnection()
    cur = db.get_cursor()
    uid = uuid.UUID(recordLocator.record_locator_id)
    cur.execute(PUT_RECORD_LOCATOR_BY_ID, (recordLocator.airline_record_locator, recordLocator.passenger_id, recordLocator.fare_class, recordLocator.bag_count, recordLocator.departure, recordLocator.arrival, recordLocator.connections))
    db.connection.commit
    return get_record_locators_by_id(uid)

####################################################################################################
# DELETE Functions begin here

def delete_agent_reservation(uid: uuid):
    db = DBConnection()
    cur = db.get_cursor()
    cur.execute(DELETE_AGENT_RESERVATIONS, [uid])
    db.connection.commit()
    return get_all_agent_reservations(uuid)

def delete_airlines(uid: uuid):
    db = DBConnection()
    cur = db.get_cursor()
    cur.execute(DELETE_AIRLINE, [uid])
    db.connection.commit()
    return get_all_airline_details(uuid)

def delete_hubs(uid: uuid):
    db = DBConnection()
    cur = db.get_cursor()
    cur.execute(DELETE_HUB, [uid])
    db.connection.commit()
    return get_all_hub_info(uuid)

def delete_passengers(uid: uuid):
    db = DBConnection()
    cur = db.get_cursor()
    cur.execute(DELETE_PASSENGER, [uid])
    db.connection.commit()
    return get_all_passenger_details(uuid)

def delete_record_locators(uid: uuid):
    db = DBConnection()
    cur = db.get_cursor()
    cur.execute(DELETE_RECORD_LOCATOR, [uid])
    db.connection.commit()
    return get_all_record_locators(uuid)

