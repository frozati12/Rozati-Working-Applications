Description of how to run the Airline Reservation System Database

Make sure the FASTAPI interface is running then proceed to "localhost" in a web browser.

Click on each function to interact with the database then click try it out to test it. 
